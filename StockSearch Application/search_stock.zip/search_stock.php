<?php
	$cname=$_GET["company"];
	$query1 = "http://query.yahooapis.com/v1/public/yql?q=Select%20Name%2C%20Symbol%2C%20LastTradePriceOnly%2C%20Change%2C%20ChangeinPercent%2C%20PreviousClose%2C%20DaysLow%2C%20DaysHigh%2C%20Open%2C%20YearLow%2C%20YearHigh%2C%20Bid%2C%20Ask%2C%20AverageDailyVolume%2C%20OneyrTargetPrice%2C%20MarketCapitalization%2C%20Volume%2C%20Open%2C%20YearLow%20from%20yahoo.finance.quotes%20where%20symbol%3D%22".$cname."%22&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
	$query2 = "http://feeds.finance.yahoo.com/rss/2.0/headline?s=".$cname."&region=US&lang=en-US";

	$xmlFinance=simplexml_load_file($query1);
	$xmlNews=simplexml_load_file($query2);
	$xmlChart="http://chart.finance.yahoo.com/t?s=".$cname."&amp;lang=en-US&amp;amp;width=300&amp;height=180";
	
	//For Finance Quotes
	$elemFinance=$xmlFinance->results->quote;
	
	$xmlDoc = new DOMDocument('1.0');
	$xmlDoc->formatOutput = true;
	
	$root = $xmlDoc->createElement('result');
	$root = $xmlDoc->appendChild($root);
	
	$title = $xmlDoc->createElement('Name');
    $title = $root->appendChild($title);
    $text = $xmlDoc->createTextNode($elemFinance->Name);
	$text = $title->appendChild($text);
	
	$title = $xmlDoc->createElement('Symbol');
    $title = $root->appendChild($title);
    $text = $xmlDoc->createTextNode($elemFinance->Symbol);
	$text = $title->appendChild($text);
	
	$title = $xmlDoc->createElement('Quote');
	$title = $root->appendChild($title);
	
	$change = $elemFinance->Change;
	$cnum = substr($change, 1);
	$csym=substr($change, 0, 1);
	
	$quotetitle = $xmlDoc->createElement('ChangeType');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode($csym);
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('Change');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode($cnum);
	$text = $quotetitle->appendChild($text);
	
	if($change<0)
	{
		$sign =-1.0;
    }
	else
	{
		$sign=1.0;
    };
       
    $quotetitle = $xmlDoc->createElement('ChangeInPercent');
    $quotetitle = $title->appendChild($quotetitle);
    $text = $xmlDoc->createTextNode(((number_format((double)$elemFinance->ChangeinPercent,2)) * $sign)."%");
    $text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('LastTradePriceOnly');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->LastTradePriceOnly), 2));
	$text = $quotetitle->appendChild($text);

	$quotetitle = $xmlDoc->createElement('PreviousClose');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->PreviousClose), 2));
	$text = $quotetitle->appendChild($text);

	$quotetitle = $xmlDoc->createElement('DaysLow');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->DaysLow), 2));
	$text = $quotetitle->appendChild($text);

	$quotetitle = $xmlDoc->createElement('DaysHigh');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->DaysHigh), 2));
	$text = $quotetitle->appendChild($text);	
	
	$quotetitle = $xmlDoc->createElement('Open');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->Open), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('YearLow');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->YearLow), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('YearHigh');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->YearHigh), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('Bid');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->Bid), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('Volume');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->Volume), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('Ask');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->Ask), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('AverageDailyVolume');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->AverageDailyVolume), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('OneYearTargetPrice');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->OneYearTargetPrice), 2));
	$text = $quotetitle->appendChild($text);
	
	$quotetitle = $xmlDoc->createElement('MarketCapitalization');
	$quotetitle = $title->appendChild($quotetitle);
	$text = $xmlDoc->createTextNode(number_format(floatval($elemFinance->MarketCapitalization), 2));
	$text = $quotetitle->appendChild($text);	
	
	//For Finance News
	$title = $xmlDoc->createElement('News');
	$title = $root->appendChild($title);
	
	$elemNews = $xmlNews->channel;
	foreach ($elemNews->children() as $child)
	{
		if($child->getName()=="item")
		{
			$newstitle = $xmlDoc->createElement("Item");
			$newstitle = $title->appendChild($newstitle);
			
			$itemtitle = $xmlDoc->createElement('Title');
			$itemtitle = $newstitle->appendChild($itemtitle);
			$text = $xmlDoc->createTextNode($child->title);
			$text = $itemtitle->appendChild($text);
			
			$itemtitle = $xmlDoc->createElement('Link');
			$itemtitle = $newstitle->appendChild($itemtitle);
			$text = $xmlDoc->createTextNode($child->link);
			$text = $itemtitle->appendChild($text);
		}
	}
	
	//For Finance Chart
	
	$title = $xmlDoc->createElement('StockChartImageURL');
    $title = $root->appendChild($title);
	$text = $xmlDoc->createTextNode($xmlChart);
    $text = $title->appendChild($text);				 
	  
	echo $xmlDoc->saveXML();
?>
			